#ifndef ENCODER_H
#define ENCODER_H

void Encoder_Init();

#endif