#ifndef Usart_H
#define Usart_H
void Serial_PrintString(unsigned char *String);
void Usart_Init(void);
void Usart_GPIO_Init(void);
#endif