#ifndef _CSB_H
#define _CSB_H

void csb_init();
unsigned int csb();

#endif