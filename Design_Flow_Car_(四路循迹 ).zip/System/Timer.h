#ifndef Timer_H
#define Timer_H
void TIM0_Init();
void TIM1_Init();
void TIM2_Init();
#endif